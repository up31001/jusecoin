from .Sha256Chain import Sha256Chain

class Jusecoin(Sha256Chain):
    def __init__(chain, **kwargs):
        chain.name = 'Jusecoin'
        chain.code3 = 'JC'
        chain.address_version = '\x00'
        chain.script_addr_vers = '\x05'
        chain.magic = '\xbe\x45\xf2\x04'
        Sha256Chain.__init__(chain, **kwargs)
