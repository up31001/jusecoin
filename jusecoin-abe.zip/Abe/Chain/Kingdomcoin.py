from .Sha256Chain import Sha256Chain

class Kingdomcoin(Sha256Chain):
    def __init__(chain, **kwargs):
        chain.name = 'Kingdomcoin'
        chain.code3 = 'KC'
        chain.address_version = '\x00'
        chain.script_addr_vers = '\x05'
        chain.magic = '\x78\x80\xd2\xab'
        Sha256Chain.__init__(chain, **kwargs)
